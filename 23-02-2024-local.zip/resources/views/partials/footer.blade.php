{{-- <div class="py-6 px-6 text-center">
    <p class="mb-0 fs-4">©
        <script>
            document.write(new Date().getFullYear())
        </script>,
        made with <i class="fa fa-heart"></i> by <a href="{{ route('dashboard') }}" class="font-weight-bold" target="_blank">HexaTech Solution</a> for a better solutions.
    </p>
</div> --}}
